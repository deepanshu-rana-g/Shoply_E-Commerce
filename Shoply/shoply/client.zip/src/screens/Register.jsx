import React from 'react'
import SignUp from '../components/Auth/Signup'
const Register = () => {
  return (
    <div>
      <SignUp/>
    </div>
  )
}

export default Register
