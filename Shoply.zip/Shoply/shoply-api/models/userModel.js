const mongoose =require('mongoose')

const userSchema = mongoose.Schema({
    username : {
        type : String,
        required : true,
    },
    email : {
        type : String,
        required : true,
    },
    password : {
        type : String,
        required : true,
    },
    isAdmin : {
        type : Boolean,
       default : false,
    }
},
{
    timestamps:true,  //when its created or updated
})

const User = mongoose.model('User', userSchema)
module.exports= User