import React from 'react'
import FeatureProducts from '../components/FeatureProducts';
import HeroSection from '../components/HeroSection';

const Home = () => {
  return (
 
        <div>  
     <HeroSection/>
    <FeatureProducts/>
        </div>
      
  )
}

export default Home