import React from 'react'
import { Typography } from '@mui/material'

const Review = () => {
  return (
    <>
    <Typography variant="h6" gutterBottom>
      Order summary
    </Typography>
    </>
  )
}

export default Review
